import dashboard from './dashboard'

// ==============================|| MENU ITEMS ||============================== //

export const menuItems = {
    items: [dashboard]
}
