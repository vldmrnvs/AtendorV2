import React from 'react'

const ConfirmContext = React.createContext()

export default ConfirmContext
